/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package reto3.reto3.Interfaz;

import org.springframework.data.repository.CrudRepository;
import reto3.reto3.Entidad.Reservation;

/**
 *
 * @author USUARIO
 */
public interface interfaceReservation extends CrudRepository<Reservation, Integer>{
    
}
